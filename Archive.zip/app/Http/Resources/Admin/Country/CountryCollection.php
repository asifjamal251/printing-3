<?php

namespace App\Http\Resources\Admin\Country;

use Illuminate\Http\Resources\Json\ResourceCollection;
use App\Http\Resources\Admin\Country\CountryResource;
class CountryCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'data' => CountryResource::collection($this->collection),
            'recordsTotal' => $request->recordsTotal,
            'recordsFiltered' => $request->recordsTotal,
            'length' => $request->lenght,
        ];
    }
}
