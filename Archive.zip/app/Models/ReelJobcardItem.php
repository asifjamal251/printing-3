<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReelJobcardItem extends Model
{
    //
}
