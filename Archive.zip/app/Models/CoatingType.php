<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CoatingType extends Model
{

    protected $fillable = [
        'name',
        'category',
        'status_id',
    ];


}
