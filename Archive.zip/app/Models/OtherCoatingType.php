<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OtherCoatingType extends Model
{

    protected $fillable = [
        'name',
        'category',
        'status_id',
    ];


}
