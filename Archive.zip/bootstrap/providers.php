<?php

return [
    App\Providers\AppServiceProvider::class,
    Spatie\Html\HtmlServiceProvider::class,
];
